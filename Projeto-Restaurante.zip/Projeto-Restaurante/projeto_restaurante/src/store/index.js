import { createStore } from 'vuex'
import Vue from 'vue'
import Vuex from 'vuex'
import axios from "axios"

export default new Vuex.Store({
  state: {
    venda: [{
      'nome': 'Beef',
      'preco': 15,
      'foto': 'https://www.themealdb.com/images/category/beef.png'
    },
    {
      'nome': 'Chicken',
      'preco': 15,
      'foto': 'https://www.themealdb.com/images/category/chicken.png'
    },
    {
      'nome': 'Dessert',
      'preco': 15,
      'foto': 'https://www.themealdb.com/images/category/dessert.png'
    },
    {
      'nome': 'Lamb',
      'preco': 15,
      'foto': 'https://www.themealdb.com/images/category/lamb.png'
    },
    {
      'nome': 'Miscellaneous',
      'preco': 15,
      'foto': 'https://www.themealdb.com/images/category/miscellaneous.png'
    },
    {
      'nome': 'Pasta',
      'preco': 15,
      'foto': 'https://www.themealdb.com/images/category/pasta.png'
    },
    {
      'nome':'Pork',
      'preco': 15,
      'foto':'https://www.themealdb.com/images/category/pork.png'
      },
      {
        'nome':'Seafood',
        'preco': 15,
        'foto':'https://www.themealdb.com/images/category/seafood.png'
        },
        {
          'nome':'Side',
          'preco': 15,
          'foto':'https://www.themealdb.com/images/category/side.png'
          },
          {
            'nome':'Starter',
            'preco': 15,
            'foto':'https://www.themealdb.com/images/category/starter.png'
            },
              {
                'nome':'Vegan',
                'preco': 15,
                'foto':'https://www.themealdb.com/images/category/vegan.png'
                },
                {
                  'nome':'Vegetarian',
                  'preco': 15,
                  'foto':'https://www.themealdb.com/images/category/vegetarian.png'
                  },
                  {
                    'nome':'Breakfast',
                    'preco': 15,
                    'foto':'https://www.themealdb.com/images/category/breakfast.png'
                    },
                    {
                      'nome':'Goat',
                      'preco': 15,
                      'foto':'https://www.themealdb.com/images/category/goat.png'
                      },
    ],
    info: [],
    favoritos: [],
    venda: [],
    user: null
  },
  getters: {
    racaVenda: state => {
      return [...new Set(state.venda.map((x)=> x.nome))]
    }
  },
  mutations: {
    setUser(state, user) {
      state.user = user
    },
    marcaFavorito(state, item) {
      state.favoritos = [item, ...state.favoritos]
      localStorage.setItem('favoritoLocal', JSON.stringify(state.favoritos))
    },
    desmarcaFavorito(state, index) {
      state.favoritos.splice(index, 1)
      localStorage.setItem('favoritoLocal', JSON.stringify(state.favoritos))
    }
  },
  actions: {
  },
  modules: {
  }
})
