<template>
<!------------------------------------------------------------------------------- MENU ------------------------------------------------------------------------------->
    <div id="home">
        <nav>

      <router-link to="/">Inicio</router-link> |
      <router-link to="/about">Sobre</router-link> |
      <router-link to="/Pratos">Pratos</router-link> |
      <router-link to="/contactos">Contactos</router-link> &nbsp;&nbsp;&nbsp;&nbsp;
      <button>
        <router-link to="/login">Iniciar Sessão</router-link>
      </button> &nbsp;&nbsp;&nbsp;&nbsp;
      <button>
        <router-link to="/carrinho"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
            class="bi bi-cart-plus" viewBox="0 0 16 16">
            <path d="M9 5.5a.5.5 0 0 0-1 0V7H6.5a.5.5 0 0 0 0 1H8v1.5a.5.5 0 0 0 1 0V8h1.5a.5.5 0 0 0 0-1H9V5.5z" />
            <path
              d="M.5 1a.5.5 0 0 0 0 1h1.11l.401 1.607 1.498 7.985A.5.5 0 0 0 4 12h1a2 2 0 1 0 0 4 2 2 0 0 0 0-4h7a2 2 0 1 0 0 4 2 2 0 0 0 0-4h1a.5.5 0 0 0 .491-.408l1.5-8A.5.5 0 0 0 14.5 3H2.89l-.405-1.621A.5.5 0 0 0 2 1H.5zm3.915 10L3.102 4h10.796l-1.313 7h-8.17zM6 14a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm7 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0z" />
          </svg></router-link>
            </button> &nbsp;&nbsp;&nbsp;&nbsp;
            <input id="input1" type="text" placeholder="Pesquise um produto"/>
            <svg class="search-icon" width="26" height="25.8" @click="carregar(text)">
                <path opacity=".4" fill="#68A1D6"
                    d="M22.3 3.7C20.5 2 18.1 1 15.6 1S10.8 2 9 3.7c-1.8 1.8-2.7 4.1-2.7 6.6 0 1.7.5 3.4 1.4 4.9l-6 6-.1.1c-.8.9-.8 2.2.1 3.1.8.8 2.2.9 3.1.1l6-6c1.5.9 3.1 1.4 4.9 1.4 2.5 0 4.9-1 6.6-2.7 3.6-3.8 3.6-9.8 0-13.5zm-2.9 10.5c-1 1-2.4 1.6-3.8 1.6s-2.8-.6-3.8-1.6-1.6-2.4-1.6-3.8.6-2.8 1.6-3.8S14.2 5 15.6 5s2.8.6 3.8 1.6c2.1 2.1 2.1 5.5 0 7.6z" />
            </svg>
    </nav>
  </div>
  <!------------------------------------------------------------------------------- FIM MENU --------------------------------------------------------------------------->
    <div class="todo">
        <div class="about">


            <ul>
                <li v-for='(prato, index) in Pratos' :key="index">
                    <div class="food"> <img :src="prato.strCategoryThumb" alt=""></div>
                    {{ prato.strCategoryDescription }}



                </li>

            </ul>
        </div>
        <p></p>
        <p></p>
        <br>
        <br>


        <br>
        <br>
    </div>
      <!-----------------------------FOOTER -------------------------------------------------------------------------------------->
  <footer class="footer-section">
    <div class="container">
      <div class="footer-content pt-5 pb-5">
        <div class="row">
          <div class="col-xl-4 col-lg-4 col-md-6 mb-30">
            <div class="footer-widget">
              <div class="footer-widget-heading">
                <h3>Links úteis</h3>
              </div>
              <ul>
                <li>
                  <router-link to="/">Inicio</router-link>
                </li>
                <li>
                  <router-link to="/about">Sobre</router-link>
                </li>
                <li>
                  <router-link to="/contactos">Contactos</router-link>
                </li>
                <li>
                  <router-link to="/pratos">Pratos</router-link>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <p>@ 2022 FermeEat - Todos os direitos reservados!</p>
  </footer>
  <!-------------------------------------------------------------- FIM FOOTER -------------------------------------------------------------------------------------->
</template>
<script>
import firebase from 'firebase'
export default {
    data() {
        return {
            Pratos: [],
            user: null,
            pesquisa: ""
        }
    },

    methods: {
        carrega() {
            this.$router.push('/carrinho')
        },
        carregar() {
            this.$router.push('/pesquisa')
        },

    },//////

    mounted() {
        this.axios.get('https://www.themealdb.com/api/json/v1/1/categories.php')
            .then(
                res => {
                    console.log(res)
                    this.Pratos = res.data.categories
                })


        this.user = firebase.auth().currentUser
    },

}
</script>
<style scoped>
.todo {
    background-color: gray;
}
</style>