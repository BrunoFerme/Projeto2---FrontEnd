import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import axios from 'axios'
import VueAxios from 'vue-axios'
import firebase from 'firebase'

const firebaseConfig = {
  apiKey: "AIzaSyCb5fEM6c5vESJh_IH96R30-tgdB7Qv-40",
  authDomain: "projeto-restaurante-front-end.firebaseapp.com",
  databaseURL: "https://projeto-restaurante-front-end-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "projeto-restaurante-front-end",
  storageBucket: "projeto-restaurante-front-end.appspot.com",
  messagingSenderId: "794178197409",
  appId: "1:794178197409:web:5667378b52daf5db105de0"
};

  firebase.initializeApp(firebaseConfig)

createApp(App).use(VueAxios, axios).use(store).use(router).mount('#app')