import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import ErrorPage from '../views/ErrorPage.vue'
import Login from '../views/login.vue'
import Registro from '../views/registro.vue'
import Teste from '../views/Teste.vue'
import Contactos from '../views/contactos.vue'
import descrição from '../views/descricao.vue'
import carrinho from '../views/carrinho.vue'
import About from '../views/AboutView.vue'
import Pesquisa from '../views/pesquisa.vue'

const routes = [
  {
    path: '/',
    name: 'home',
    component: HomeView
  },
  {
    path: '/login',
    name: 'login',
    component: Login
  },
  {
    path: '/registro',
    name: 'registro',
    component: Registro
  },
  {
    path: '/carrinho',
    name: 'carrinho',
    component: carrinho
  },
  {
  path: '/teste',
  name: 'teste',
  component: Teste
  },
  {
    path: '/contactos',
    name: 'contactos',
    component: Contactos
    },
  {
      path: '/about',
      name: 'about',
      component: About
    },
    {
      path: '/pesquisa',
      name: 'pesquisa',
      component: Pesquisa
    },
    {
      path: '/descricao',
      name: 'descricao',
      component: descrição
    },
  {
    path: '/Pratos',
    name: 'Pratos',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: function () {
      return import(/* webpackChunkName: "about" */ '../views/Pratos.vue')
    }
  },
  {
    path: '/:catchAll(.*)',
    name: 'errorpage',
    component: ErrorPage
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
